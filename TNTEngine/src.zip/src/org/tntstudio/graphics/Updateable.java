package org.tntstudio.graphics;

public interface Updateable {
	public void update(float delta);
}
