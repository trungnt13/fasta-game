
package org.tntstudio.graphics.objs;

public class CollisionChecker {

}
