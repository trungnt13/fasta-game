
package org.tntstudio.utils.encode;


public final class IOSCrypto extends AndroidCrypto {
}
