
package org.tntstudio.core;

/** Under-constructor
 * @author trungnt13 */
public class SplashScreen {

}
