
package org.tntstudio.box2d;

import com.badlogic.gdx.physics.box2d.PolygonShape;

/** Use like PolygonShape
 * @author trungnt13 */
public final class LuaPolygonShape extends PolygonShape {

}
