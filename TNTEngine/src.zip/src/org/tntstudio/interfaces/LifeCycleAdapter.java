
package org.tntstudio.interfaces;

public abstract class LifeCycleAdapter implements LifecycleListener {
	@Override
	public void dispose () {
	}

	@Override
	public void resume () {
	}

	@Override
	public void pause () {
	}
}
