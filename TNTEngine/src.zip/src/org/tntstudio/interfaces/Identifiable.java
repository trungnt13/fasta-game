package org.tntstudio.interfaces;

public interface Identifiable {
	public String Name();
}
