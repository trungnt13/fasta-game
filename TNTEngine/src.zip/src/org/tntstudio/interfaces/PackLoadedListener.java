
package org.tntstudio.interfaces;

public interface PackLoadedListener {
	public void packCompletedLoading ();
}
