package org.tntstudio.ui;

public class ConfirmDialog {

	
	
	
}
