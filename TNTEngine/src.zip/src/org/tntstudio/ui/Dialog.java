package org.tntstudio.ui;

public class Dialog {

}
