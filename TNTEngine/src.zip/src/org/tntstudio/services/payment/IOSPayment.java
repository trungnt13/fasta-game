package org.tntstudio.services.payment;

public class IOSPayment {

}
