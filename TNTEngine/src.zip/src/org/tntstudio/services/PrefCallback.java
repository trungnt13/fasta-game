
package org.tntstudio.services;


public interface PrefCallback {
	public void prefLoaded (TNTPreference pref);
}
