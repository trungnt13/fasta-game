Prerequisite:
	gcc >= 4.8

Running:
	1. open terminal
  2. cd /path/to/source/folder
	3. make
	5. ./n2ttranslator
	6. enjoy

Option for another language:
	-d dictvn.txt(For Vietnamese) or dicten.txt(For English)

For more information:
	1. make help (for help)
	2. make love (amazing credit)
	3. ./n2ttranslator -h (after a successful build)
	4. send email to: trungnt13@gmail.com
